package com.ahmedomara.jadwaldrosey;
import android.app.*;
import android.content.*;
import android.os.*;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c, Intent i) {
   String ch="lesson_reminders";
   NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
   if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"تنبيهات الدروس",NotificationManager.IMPORTANCE_HIGH));
   Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);
   b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(i.getStringExtra("title")).setContentText(i.getStringExtra("text")).setAutoCancel(true);
   nm.notify((int)(System.currentTimeMillis()%100000),b.build());
 }
}
